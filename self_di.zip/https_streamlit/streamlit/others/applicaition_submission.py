import streamlit as st
import pandas as pd
from common_page_content import common_page_content
from pages.application_confirmation import application_confirmation

def load_bundle(locale, csv_file_mapping):
    csv_file_path = f"{csv_file_mapping[locale]}.csv"
    try:
        df = pd.read_csv(csv_file_path)
        lang_dict = {df.key.to_list()[i]: df.value.to_list()[i] for i in range(len(df.key.to_list()))}
        return lang_dict
    except FileNotFoundError:
        st.error(f"CSV file not found at path: {csv_file_path}")
        return {}
    except Exception as e:
        st.error(f"An error occurred while loading the CSV file: {e}")
        return {}
    
    
# def common_page_content():
#     # Define language to locale mapping
#     language_to_locale = {
#         "english": "english",
#         "japanese": "japanese",
#         # Add more languages as needed
#     }

#     # Define CSV file mapping
#     csv_file_mapping = {
#         "english": "english",
#         "japanese": "japanese"
#     }
    
    
#     if 'page' not in st.session_state:
#         st.session_state.page = 'application_confirmation'

        

#     # Get the language from the URL parameter
#     language = st.experimental_get_query_params().get("language", [""])[0]

#     # Set the language in session state
#     st.session_state.language = language

#     # Map the language to a locale (default to "english" if not found)
#     locale = language_to_locale.get(language, "english")

#     # Load language-specific CSV file
#     lang_dict = load_bundle(locale, csv_file_mapping)


#     ApplyForDataIngestionJob_key = 'ApplyforDataIngestionJob'
#     ApplyForDataIngestionJob_text = lang_dict.get(ApplyForDataIngestionJob_key, ApplyForDataIngestionJob_key)
#     # Set the title of the app
#     st.title(lang_dict.get(ApplyForDataIngestionJob_text,ApplyForDataIngestionJob_text))

#     # Create a container to hold the DI information
#     di_information = st.container()
    
#     DIInformation_key = 'DIInformation'
#     DIInformation_key_text = lang_dict.get(DIInformation_key, DIInformation_key)
    
#     # Add the DI information to the DI information container
#     di_information.text(DIInformation_key_text)
    
    
#     # Add a selectbox for Global Capability
#     global_capability_key = 'GlobalCapability'
#     global_capability_text = lang_dict.get(global_capability_key, global_capability_key)
#     global_capability = st.selectbox(global_capability_text, ["Select", "sales", "aftersales"])
    
    
#     ProjectID_key = 'ProjectID'
#     ProjectID_text = lang_dict.get(ProjectID_key, ProjectID_key)

    
#     # Add a text input for the project ID
#     project_id = st.text_input(lang_dict.get(ProjectID_text,ProjectID_text), placeholder="Example: FR01234")

#     Stage_key = 'Stage'
#     Stage_text = lang_dict.get(Stage_key, Stage_key)
    
    
#     # Add a selectbox for the stage of the project
#     stage = st.selectbox(Stage_text, ["Select", "QA", "PROD"])

#     # Create a container to hold the application materials
#     application_materials = st.container()
    
#     ApplicationMaterials_key = 'ApplicationMaterials'
#     ApplicationMaterials_text = lang_dict.get(ApplicationMaterials_key, ApplicationMaterials_key)
    

#     # Add the application materials to the application materials container
#     application_materials.subheader(ApplicationMaterials_text)
#     application_materials.file_uploader("Application Form", type=["pdf", "doc", "docx","xlsx"])
#     application_materials.file_uploader("Sample", type=["pdf", "doc", "docx","xlsx"])
#     application_materials.file_uploader("Supplementary", type=["pdf", "doc", "docx","xlsx"])


def application_submission():
#     # Define language to locale mapping
#     language_to_locale = {
#         "english": "english",
#         "japanese": "japanese",
#         # Add more languages as needed
#     }

#     # Define CSV file mapping
#     csv_file_mapping = {
#         "english": "english",
#         "japanese": "japanese"
#     }
    
    
#     if 'page' not in st.session_state:
#         st.session_state.page = 'application_confirmation'

        

#     # Get the language from the URL parameter
#     language = st.experimental_get_query_params().get("language", [""])[0]

#     # Set the language in session state
#     st.session_state.language = language

#     # Map the language to a locale (default to "english" if not found)
#     locale = language_to_locale.get(language, "english")

#     # Load language-specific CSV file
#     lang_dict = load_bundle(locale, csv_file_mapping)


#     ApplyForDataIngestionJob_key = 'ApplyforDataIngestionJob'
#     ApplyForDataIngestionJob_text = lang_dict.get(ApplyForDataIngestionJob_key, ApplyForDataIngestionJob_key)
#     # Set the title of the app
#     st.title(lang_dict.get(ApplyForDataIngestionJob_text,ApplyForDataIngestionJob_text))

#     # Create a container to hold the DI information
#     di_information = st.container()
    
#     DIInformation_key = 'DIInformation'
#     DIInformation_key_text = lang_dict.get(DIInformation_key, DIInformation_key)
    
#     # Add the DI information to the DI information container
#     di_information.text(DIInformation_key_text)
    
    
#     # Add a selectbox for Global Capability
#     global_capability_key = 'GlobalCapability'
#     global_capability_text = lang_dict.get(global_capability_key, global_capability_key)
#     global_capability = st.selectbox(global_capability_text, ["Select", "sales", "aftersales"])
    
    
#     ProjectID_key = 'ProjectID'
#     ProjectID_text = lang_dict.get(ProjectID_key, ProjectID_key)

    
#     # Add a text input for the project ID
#     project_id = st.text_input(lang_dict.get(ProjectID_text,ProjectID_text), placeholder="Example: FR01234")

#     Stage_key = 'Stage'
#     Stage_text = lang_dict.get(Stage_key, Stage_key)
    
    
#     # Add a selectbox for the stage of the project
#     stage = st.selectbox(Stage_text, ["Select", "QA", "PROD"])

#     # Create a container to hold the application materials
#     application_materials = st.container()
    
#     ApplicationMaterials_key = 'ApplicationMaterials'
#     ApplicationMaterials_text = lang_dict.get(ApplicationMaterials_key, ApplicationMaterials_key)
    

#     # Add the application materials to the application materials container
#     application_materials.subheader(ApplicationMaterials_text)
#     application_materials.file_uploader("Application Form", type=["pdf", "doc", "docx","xlsx"])
#     application_materials.file_uploader("Sample", type=["pdf", "doc", "docx","xlsx"])
#     application_materials.file_uploader("Supplementary", type=["pdf", "doc", "docx","xlsx"])
    
    
        
#     if st.session_state.page == 'application_confirmation': 
#         application_confirmation()
    
    # Common content between application confirmation and submission
    common_page_content()
    
    # Add a quit button
    submit_button = st.button('Upload')

    
    if submit_button:
        st.session_state.page = 'application_confirmation'        
        application_confirmation()
        st.rerun()

    
if __name__ == "__main__":
#     applicaition_submission()
    pass