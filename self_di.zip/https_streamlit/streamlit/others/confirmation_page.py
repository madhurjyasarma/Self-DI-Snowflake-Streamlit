import streamlit as st
import pandas as pd


def load_bundle(locale, csv_file_mapping):
    csv_file_path = f"{csv_file_mapping[locale]}.csv"
    try:
        df = pd.read_csv(csv_file_path)
        lang_dict = {df.key.to_list()[i]: df.value.to_list()[i] for i in range(len(df.key.to_list()))}
        return lang_dict
    except FileNotFoundError:
        st.error(f"CSV file not found at path: {csv_file_path}")
        return {}
    except Exception as e:
        st.error(f"An error occurred while loading the CSV file: {e}")
        return {}

def main():
    
    # Define language to locale mapping
    language_to_locale = {
        "english": "english",
        "japanese": "japanese",
    }

    # Define CSV file mapping
    csv_file_mapping = {
        "english": "english",
        "japanese": "japanese"
    }
    
    
    
    
    # Get the language from the URL parameter
    language = st.experimental_get_query_params().get("language", [""])[0]

    # Set the language in session state
    st.session_state.language = language

    # Map the language to a locale (default to "english" if not found)
    locale = language_to_locale.get(language, "english")

    # Load language-specific CSV file
    lang_dict = load_bundle(locale, csv_file_mapping)
    
    
    
    ApplicationSubmissionSuccessful_key = 'ApplicationSubmissionSuccessful'
    ApplicationSubmissionSuccessful_text = lang_dict.get(ApplicationSubmissionSuccessful_key, ApplicationSubmissionSuccessful_key)
    st.title(lang_dict.get(ApplicationSubmissionSuccessful_text,ApplicationSubmissionSuccessful_text))
    
    
    Yourapplicationhasbeensubmittedsuccessfully_key = 'Yourapplicationhasbeensubmittedsuccessfully'
    Yourapplicationhasbeensubmittedsuccessfully_text = lang_dict.get(Yourapplicationhasbeensubmittedsuccessfully_key, Yourapplicationhasbeensubmittedsuccessfully_key)
    st.write(lang_dict.get(Yourapplicationhasbeensubmittedsuccessfully_text,Yourapplicationhasbeensubmittedsuccessfully_text))
    
    
    Normallyittakesabout30minutesforvalidation_key = 'Normallyittakesabout30minutesforvalidation'
    Normallyittakesabout30minutesforvalidation_text = lang_dict.get(Normallyittakesabout30minutesforvalidation_key, Normallyittakesabout30minutesforvalidation_key)
    st.write(lang_dict.get(Normallyittakesabout30minutesforvalidation_text,Normallyittakesabout30minutesforvalidation_text))
    
    
    Theresultswillbenotifiedviaemaillater_key = 'Theresultswillbenotifiedviaemaillater'
    Theresultswillbenotifiedviaemaillater_text = lang_dict.get(Theresultswillbenotifiedviaemaillater_key, Theresultswillbenotifiedviaemaillater_key)
    st.write(lang_dict.get(Theresultswillbenotifiedviaemaillater_text,Theresultswillbenotifiedviaemaillater_text))
    
    Thankyou_key = 'Thankyou'
    Thankyou_text = lang_dict.get(Thankyou_key, Thankyou_key)
    st.write(lang_dict.get(Thankyou_text,Thankyou_text))
    
    
    
    # Set the page title
#     st.title('Application Submission Successful')

    # Display a success message
#     st.write('Your application has been submitted successfully.')

    # Display the validation time
#     st.write('Normally it takes about 30 minutes for validation.')

    # Display the notification method
#     st.write('The results will be notified via email later.')

    # Display a thank you message
#     st.write('Thank you.')

    # Add a quit button
    st.button('Quit', on_click=st.stop)
    
if __name__ == "__main__":
    main()