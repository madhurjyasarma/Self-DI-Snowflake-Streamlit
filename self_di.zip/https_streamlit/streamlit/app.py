# Main app file
# importing dependencies
import streamlit as st

from Screens.ApplicationConfirmation import application_confirmation
from Screens.ApplicationSubmission import application_submission
from Screens.SubmitPage import submit_successfully
from Screens.ApplicationSearch import application_search
from Screens.Reapplication import reapplication
from Screens.ApplicationStatusWithError import application_status_with_error
import snowflake.connector
import datetime
from snowflake.snowflake_conn import snowflake_conn

from snowflake.application_data_reg import execute_data_insertion
import boto3

from botocore.exceptions import NoCredentialsError


def upload_to_s3(file_path, bucket_name, project_id, application_id):
    s3 = boto3.client('s3')

    try:
        # Format the S3 key based on the specified path structure
        s3_key = f"{project_id}/{application_id}/{file_path.name}"

        # Upload the file to S3
        s3.upload_file(file_path, bucket_name, s3_key)

#         print(f"File uploaded successfully to S3: s3://{bucket_name}/{s3_key}")
        return f"s3://{bucket_name}/{s3_key}"

    except NoCredentialsError:
        print("AWS credentials not available or invalid. Please check your credentials.")
        return None


def generate_appid(ctx):
    today_date = datetime.date.today().strftime('%Y-%m-%d')
#     today_date = "2024-02-01"
#     st.write(f"full: {today_date}")
#     st.write(f"sliced: {today_date[:7]}")

    select_query = f"SELECT CRT_DTTM FROM T_ENTRY WHERE CRT_DTTM LIKE '{today_date[:7]}%'"
    result_rows = execute_select_statement(ctx, select_query)

#     st.text(f"This is result_row : {result_rows}")

    # Calculate the sequence number based on the number of entries
    seq_number = len(result_rows) + 1
#     st.text(f"Sequence number: {seq_number}")

    # Generate appId
    year_month = today_date[:7].replace('-', '')
    app_id = f"{year_month}{seq_number:04d}"

#     print("Generated appId:", app_id)
    return app_id


def execute_select_statement(ctx, select_query):
    cs = ctx.cursor()
    cs.execute(select_query)
    rows = cs.fetchall()
    return rows

def date_data(result_rows):
    
    date_list = []    
    for row in result_rows:
        # Extract the datetime object from the list
        datetime_obj = row[0]

        # Extract year, month, and date from the datetime object
        year = datetime_obj.year
        month = datetime_obj.month
        day = datetime_obj.day

        # Append the extracted values to the date_list
        date_list.append(f"{year}-{month:02d}-{day:02d}")

#     st.write(date_list)
    return date_list

# Start
try:
    # Connection to snowflake
    ctx = snowflake_conn()
    # testing purposes
#     if ctx:
#         st.write("Snowflake Connection Success")
 
#     username = st.experimental_get_query_params().get("user_id", [""])[0]
    try:
        username = st.query_params["user_id"]
    except KeyError:
        st.text("No username has been passed in URL")
#     st.text(f"username: {username}")
    
    #Enable once embed in wordpress using iframe
    st.session_state['username'] = username
#     st.text(f"Username session : {st.session_state['username']}")
  
    
    app_id = generate_appid(ctx)
    st.session_state['app_id'] = app_id

except:
    st.error("Snowflake connectivity error")
    st.stop()    
    
    
if 'page' not in st.session_state:
    st.session_state['page'] = 'ApplicationSubmission'
    
if 'submission' not in st.session_state:
    st.session_state['submission'] = False   

if 'reapplication' not in st.session_state:
    st.session_state['reapplication'] = False    

if 'fromReapplication' not in st.session_state:
    st.session_state['fromReapplication'] = False


if 'applicationid' not in st.session_state:
    st.session_state['applicationid'] = False
    
if 'first_data_object' not in st.session_state:
    st.session_state['first_data_object'] = True
    
if 'submit_successfully_page_flag' not in st.session_state:
    st.session_state['submit_successfully_page_flag'] = False
    
    

# Checks the applicationId is there in URL param
# application_id = st.experimental_get_query_params().get("applicationId", [""])[0]
# application_id = st.query_params["applicationId"]

try:
    application_id = st.query_params["applicationId"]
except KeyError:
    application_id = False
    
st.session_state['applicationid'] = application_id

# st.text(f"fromReapplication: {st.session_state['fromReapplication']}")



# Controls the page transitions
if application_id:
    if st.session_state['submit_successfully_page_flag']:
        submit_successfully()
 
    elif st.session_state['page'] == 'error_page':
        application_status_with_error()
    elif st.session_state['page'] == 'Reapplication':
        reapplication()        
    elif st.session_state['reapplication']:
        application_confirmation()         
    
    else:
        application_search()


else:

# #     Do not remove below code
# #     setting ApplicationSubmission page a first page
    if 'page' not in st.session_state:
        st.session_state['page'] ='ApplicationSubmission'

    # calling respective pages by session.page
    if st.session_state.page == 'application_confirmation':
        application_confirmation()

    if st.session_state['page'] == 'ApplicationSubmission':
        application_submission()

    if st.session_state['page'] == 'SubmitPage':
        submit_successfully()


