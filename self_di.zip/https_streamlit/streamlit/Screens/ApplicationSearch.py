import streamlit as st
import pandas as pd
import snowflake.connector


def snowflake_conn():
    SNOW_ACCOUNT = 'of95864.ap-northeast-1.privatelink'
    SNOW_USER = 'NDH00883'
    SNOW_PASS = 'Ni$$an@785685'
    SNOW_ROLE = 'SANDBOX_NDI_PF_DEV'
    SNOW_DB = 'SELF_DI'
    SNOW_SCHEMA = 'PUBLIC'
    SNOW_WAREHOUSE = 'SANDBOX_NDI_PF_DEV'

    # Connect to Snowflake table
    ctx = snowflake.connector.connect(
        user=SNOW_USER,
        password=SNOW_PASS,
        account=SNOW_ACCOUNT,
        role=SNOW_ROLE,
        warehouse=SNOW_WAREHOUSE,
        database=SNOW_DB,
        schema=SNOW_SCHEMA
    )

    cs = ctx.cursor()

    return ctx

def load_bundle(locale, csv_file_mapping):
    csv_file_path = f"streamlit/csv/{csv_file_mapping[locale]}.csv"
    try:
        df = pd.read_csv(csv_file_path)
        lang_dict = {df.key.to_list()[i]: df.value.to_list()[i] for i in range(len(df.key.to_list()))}
        return lang_dict
    except FileNotFoundError:
        st.error(f"CSV file not found at path: {csv_file_path}")
        return {}
    except Exception as e:
        st.error(f"An error occurred while loading the CSV file: {e}")
        return {}
    
def check_id_exist_in_contact(ctx, logged_in_user_id):
    try:
        cs = ctx.cursor()

        # Query to check if the logged-in User ID (Corporate ID) exists in T_CONTACT table
        query = f"SELECT COUNT(*) FROM T_CONTACT WHERE USR_ID = '{logged_in_user_id}'"
        cs.execute(query)
        result = cs.fetchone()[0]
#         st.text(f"result {result}")

        # Check the result
        if result == 0:
            st.error(f"{logged_in_user_id} is not accepted for updating application.")
            st.stop()  # Stop further processing
            

    except Exception as e:
        st.error(f"An error occurred while checking User ID in T_CONTACT table: {e}")
        st.stop()

def application_search():
    ctx = snowflake_conn()
    
    if 'page' not in st.session_state:
        st.session_state['page'] = 'ApplicationSearch'
        
    user_id = st.session_state['username']
    check_id_exist_in_contact(ctx,user_id)
    
    
    
    # Define language to locale mapping
    language_to_locale = {
        "english": "english",
        "japanese": "japanese",
        # Add more languages as needed
    }

    # Define CSV file mapping
    csv_file_mapping = {
        "english": "english",
        "japanese": "japanese"
    }
    # Get the language from the URL parameter
#     language = st.experimental_get_query_params().get("language", [""])[0]
    language = st.query_params.get("language", "english")

    # Set the language in session state
    st.session_state.language = language

    # Map the language to a locale (default to "english" if not found)
    locale = language_to_locale.get(language, "english")

    # Load language-specific CSV file
    lang_dict = load_bundle(locale, csv_file_mapping)
    
    ChecktheStatusofanExistedApplication_key = 'ChecktheStatusofanExistedApplication'
    ChecktheStatusofanExistedApplication_text = lang_dict.get(ChecktheStatusofanExistedApplication_key, ChecktheStatusofanExistedApplication_key)
    # Set the title of the app
    st.title(lang_dict.get(ChecktheStatusofanExistedApplication_text,ChecktheStatusofanExistedApplication_text))    
    
    ApplicationInformation_key = 'ApplicationInformation'
    ApplicationInformation_text = lang_dict.get(ApplicationInformation_key, ApplicationInformation_key)
    # Set the title of the app
    st.subheader(lang_dict.get(ApplicationInformation_text,ApplicationInformation_text))
    
    
    SelfDIApplicationID_key = 'SelfDIApplicationID'
    SelfDIApplicationID_text = lang_dict.get(SelfDIApplicationID_key, SelfDIApplicationID_key)
    # Set the title of the app
    SelfDIApplicationID_str = lang_dict.get(SelfDIApplicationID_text,SelfDIApplicationID_text)
    
    Example_key = 'Example'
    Example_text = lang_dict.get(Example_key, Example_key)
    # Set the title of the app
    Example_text_str = lang_dict.get(Example_text,Example_text)

    application_id = st.text_input(f"{SelfDIApplicationID_str}", f"{st.session_state['applicationid']}")
    
    Search_key = 'Search'
    Search_text = lang_dict.get(Search_key, Search_key)
    # Set the title of the app
    Search_text_str = lang_dict.get(Search_text,Search_text)


    SearchingforapplicationwithID_key = 'SearchingforapplicationwithID'
    SearchingforapplicationwithID_text = lang_dict.get(SearchingforapplicationwithID_key, SearchingforapplicationwithID_key)
    # Set the title of the app
    SearchingforapplicationwithID_text_str = lang_dict.get(SearchingforapplicationwithID_text,SearchingforapplicationwithID_text)

    
    if st.button(Search_text_str):
        st.session_state.page = 'error_page'      
        st.rerun()
