import streamlit as st
import pandas as pd
import snowflake
from datetime import datetime
import zipfile
import io
import os
import boto3

from io import BytesIO


from botocore.exceptions import NoCredentialsError



def log_update():

#     app_id_to_fetch = '2024010088'
    app_id_to_fetch = app_id
    entry_query = f"SELECT * FROM T_ENTRY WHERE SELFDI_APP_ID = '{app_id_to_fetch}'"

    cursor = ctx.cursor()
    cursor.execute(entry_query)
    entry_data = cursor.fetchall()

    if entry_data:
        # Unpack the data
        (
            selfdi_app_id,
            attempt,
            prjct_id,
            application_form,
            sample_file,
            supplementary,
            storage_location,
            crt_usr_id,
            crt_dttm,
            updt_usr_id,
            updt_dttm,
        ) = entry_data[0]


        prjct_id = uploaded_files.get('project_id', '')
        application_form = uploaded_files.get('application_form_name', '')
        sample_file = uploaded_files.get('sample_name', '')
        supplementary = uploaded_files.get('supplementary_name', '')



        # Use the unpacked values as needed
        st.text(f"SELFDI_APP_ID: {selfdi_app_id}")
        st.text(f"ATTEMPT: {attempt}")
        st.text(f"PRJCT_ID: {prjct_id}")
        st.text(f"Application Form: {application_form}")
        st.text(f"Sample File: {sample_file}")
        st.text(f"Supplementary: {'Y' if supplementary else 'N'}")
        st.text(f"Storage Location: {storage_location}")
        st.text(f"CRT_USR_ID: {crt_usr_id}")
        st.text(f"CRT_DTTM: {crt_dttm}")
        st.text(f"UPDT_USR_ID: {updt_usr_id}")
        st.text(f"UPDT_DTTM: {updt_dttm}")

        # Delete the existing record
        delete_query = f"DELETE FROM T_ENTRY WHERE SELFDI_APP_ID = '{selfdi_app_id}'"
        ctx.cursor().execute(delete_query)
        st.text(f"Deleted record with SELFDI_APP_ID: {selfdi_app_id}")

        # Increment the ATTEMPT value and insert a new record
        new_attempt = attempt + 1
        insert_query = f"""
            INSERT INTO T_ENTRY (
                SELFDI_APP_ID, ATTMPT, PRJCT_ID, APPLICTINFRM, SMPL_FL,
                SPPLMNTRY, STRG_LCTN, CRT_USR_ID, CRT_DTTM, UPDT_USR_ID, UPDT_DTTM
            ) VALUES (
                '{selfdi_app_id}', {new_attempt}, '{prjct_id}', ''{application_form}'', '{sample_file}',
                {supplementary}, '{storage_location}', '{crt_usr_id}', '{crt_dttm}', '{updt_usr_id}', '{updt_dttm}'
            )
        """

        st.text(f"Insert query: {insert_query}")
        ctx.cursor().execute(insert_query)
        st.text(f"Inserted new record with SELFDI_APP_ID: {selfdi_app_id} and ATTEMPT: {new_attempt}")
    else:
        st.error(f"No data found for SELFDI_APP_ID: {app_id_to_fetch}")



def read_excel(excel_file_path, sheet_name):
    df = pd.read_excel(excel_file_path, sheet_name=sheet_name, header=1, engine='openpyxl')
    return df
 
def process_dataframe(df):
    missing_values = df['Role'].isna().sum()
    print(f"Number of missing values in the 'Role' column: {missing_values}")
    df = df[df['Role'].notna()]
#     print(df)
    return df

 
def execute_query(conn, qry, values=None):
    try:
        cursor = conn.cursor()
        # print("Executing query:", qry)
        if values:
            res = cursor.execute(qry, values).fetchall()
        else:
            res = cursor.execute(qry).fetchall()
#         print("result .... ")
#         print(res)
        return res
    except Exception as e:
        print(f"Error executing query: {str(e)}")
        return None
#     finally:
#         cursor.close()
 
def response(result, selfdi_app_id, df, ctx):
    sf_selfdi_app_id_list = [id[0] for id in result]
    print("sf_selfdi_app_id_list : ", sf_selfdi_app_id_list)

    status = selfdi_app_id not in sf_selfdi_app_id_list
    print("status : ", status)

    snowflake_conn = ctx

    if status:
        insert_records(snowflake_conn, selfdi_app_id, df)
        print("Records inserted into Snowflake table.")
    else:
        delete_record(snowflake_conn, selfdi_app_id)
        insert_records(snowflake_conn, selfdi_app_id, df)
        print("Record deleted and inserted from Snowflake table.")

#     snowflake_conn.close()

    return status


def insert_records(conn, selfdi_app_id, df):
    crt_usr_id = st.session_state['user_id']
    st.text(f"{st.session_state['user_id']}")
    
    current_timestamp = 'CURRENT_TIMESTAMP'  
    insert_values = []

    for index, row in df.iterrows():
        is_mngnt = row['Role'] == 'Project Leader'
        is_pm = row['Role'] == 'Project Manager'

        insert_values.append(f"('{selfdi_app_id}', '{row['Dept ID']}', '{row['First Name']}', '{row['Last Name']}', "
                            f"'{row['Corporate ID']}', '{row['Email Address']}', {is_mngnt}, {is_pm}, "
                            f"'{crt_usr_id}', {current_timestamp}, '{crt_usr_id}', {current_timestamp})")

    insert_query = f"""
    INSERT INTO T_CONTACT (SELFDI_APP_ID,DPRTMNT_ID,FRST_NM,LST_NM,USR_ID,EML,IS_MNGNT,IS_PM,CRT_USR_ID,CRT_DTTM,UPDT_USR_ID,UPDT_DTTM) VALUES
    {', '.join(insert_values)};
    """
#     print("insert_query : ",insert_query)
    execute_query(conn, insert_query)
#     st.text(insert_query)
    print("Records inserted successfully.")


def delete_record(conn, selfdi_app_id):
    delete_query = f"DELETE FROM T_CONTACT WHERE SELFDI_APP_ID = '{selfdi_app_id}';"
#     print("delete_query : ",delete_query)
    execute_query(conn, delete_query)
#     print("Record deleted successfully.")




def upload_to_s3(file_content, bucket_name, project_id, application_id,file_name):
    s3 = boto3.client('s3')

    try:
        # Format the S3 key based on the specified path structure
        s3_key = f"{project_id}/{application_id}/{file_name}"

        # Upload the file content to S3
        s3.put_object(Body=file_content, Bucket=bucket_name, Key=s3_key)

        st.text(f"File uploaded successfully to S3: s3://{bucket_name}/{s3_key}")
        return f"s3://{bucket_name}/{s3_key}"

    except NoCredentialsError:
        print("AWS credentials not available or invalid. Please check your credentials.")
        return None
    



def snowflake_conn():
    SNOW_ACCOUNT = 'of95864.ap-northeast-1.privatelink'
    SNOW_USER = 'NDH00883'
    SNOW_PASS = 'Ni$$an@785685'
    SNOW_ROLE = 'SANDBOX_NDI_PF_DEV'
    SNOW_DB = 'SELF_DI'
    SNOW_SCHEMA = 'PUBLIC'
    SNOW_WAREHOUSE = 'SANDBOX_NDI_PF_DEV'

    # Connect to Snowflake table
    ctx = snowflake.connector.connect(
        user=SNOW_USER,
        password=SNOW_PASS,
        account=SNOW_ACCOUNT,
        role=SNOW_ROLE,
        warehouse=SNOW_WAREHOUSE,
        database=SNOW_DB,
        schema=SNOW_SCHEMA
    )

    cs = ctx.cursor()

    return ctx


def insert_into_database(data_object):
    # Implement your database insertion logic here
    # Access the data_object attributes as needed, for example: data_object['application_form_name']
    pass

def data_from_screen():
    if 'uploaded_files' in st.session_state:
        application_form_name = st.session_state.uploaded_files.get('application_form_name', "No application form uploaded yet.")
        sample_name = st.session_state.uploaded_files.get('sample_name', "No sample uploaded yet.")
        supplementary_name = st.session_state.uploaded_files.get('supplementary_name', "No supplementary uploaded yet.")

        # Create a dictionary to store the extracted data
        data_object = {
            'application_form_name': application_form_name,
            'sample_name': sample_name,
            'supplementary_name': supplementary_name
        }

        # Now you can use the data_object as needed, for example, to insert into a database
        insert_into_database(data_object)

        # Display the extracted data on the Streamlit app
#         st.text(f"Application Form: {application_form_name}")
#         st.text(f"Sample: {sample_name}")
#         st.text(f"Supplementary: {supplementary_name}")
    else:
        st.text("No files uploaded yet.")
    

def load_bundle(locale, csv_file_mapping):
    csv_file_path = f"streamlit/csv/{csv_file_mapping[locale]}.csv"
    try:
        df = pd.read_csv(csv_file_path)
        lang_dict = {df.key.to_list()[i]: df.value.to_list()[i] for i in range(len(df.key.to_list()))}
        return lang_dict
    except FileNotFoundError:
        st.error(f"CSV file not found at path: {csv_file_path}")
        return {}
    except Exception as e:
        st.error(f"An error occurred while loading the CSV file: {e}")
        return {}

def execute_insert_query(ctx, data_object):
    # Extract data from the data_object
    sel_di_app_id = data_object.get('SELFDI_APP_ID', '')
    attempt = data_object.get('ATTMPT', '')
    project_id = data_object.get('PRJCT_ID', '')
    application_frm = data_object.get('APPLICTINFRM', '')  # Handle the case where the key might not exist
    sample_file = data_object.get('SMPL_FL', '')  # Handle the case where the key might not exist
    supplementary = 'Y' if data_object.get('SPPLMNTRY', '') == 'Y' else 'N'  # Handle the case where the key might not exist
    storage_location = data_object.get('STRG_LCTN', '')  # Handle the case where the key might not exist
    crt_usr_id = data_object.get('CRT_USR_ID', '')  # Handle the case where the key might not exist
    crt_dttm = data_object.get('CRT_DTTM', '')  # Handle the case where the key might not exist
    updt_usr_id = data_object.get('UPDT_USR_ID', '')  # Handle the case where the key might not exist
    updt_dttm = data_object.get('UPDT_DTTM', '')  # Handle the case where the key might not exist

    # Construct the SQL insert query
    sql_insert_query = f"INSERT INTO T_ENTRY (SELFDI_APP_ID, ATTMPT, PRJCT_ID, APPLICTINFRM, SMPL_FL, SPPLMNTRY, STRG_LCTN, CRT_USR_ID, CRT_DTTM, UPDT_USR_ID, UPDT_DTTM) VALUES " \
                       f"('{sel_di_app_id}', {attempt}, '{project_id}', '{application_frm}', '{sample_file}', '{supplementary}', '{storage_location}', '{crt_usr_id}', '{crt_dttm}', '{updt_usr_id}', '{updt_dttm}')"

#     print(sql_insert_query)
#     st.text("Insert query ran successfully!")
    return sql_insert_query



def create_data_object(app_id, s3_loc, uploaded_files):
    st.text(f"Uploaded files: {uploaded_files}")
    data_object = {
        'SELFDI_APP_ID': st.session_state['app_id'],
        'ATTMPT': 1,
        'PRJCT_ID': uploaded_files.get('project_id', ''),
        'APPLICTINFRM': uploaded_files.get('application_form_name', ''),
        'SMPL_FL': uploaded_files.get('sample_name', ''),
        'SPPLMNTRY': 'Y' if uploaded_files.get('supplementary_name') else 'N',
        'STRG_LCTN': s3_loc,
        'CRT_USR_ID': f"{st.session_state['user_id']}",
        'CRT_DTTM': datetime.now().strftime('%Y-%m-%d %H:%M:%S -08:00'),
        'UPDT_USR_ID': 'NDH00883',
        'UPDT_DTTM': datetime.now().strftime('%Y-%m-%d %H:%M:%S -08:00')
    }

    return data_object




def create_uploaded_file(project_id, uploaded_application_form, uploaded_sample, uploaded_supplementary):
    uploaded_files = {
        'application_form_name': uploaded_application_form.name if uploaded_application_form else None,
        'sample_name': uploaded_sample.name if uploaded_sample else None,
        'supplementary_name': uploaded_supplementary.name if uploaded_supplementary else None,
        'project_id': project_id
    }
    st.session_state.uploaded_files = uploaded_files
#     st.text("Variables set in session_state")
    return uploaded_files

def is_zip_file(file_content):
    try:
        # Attempt to read the ZIP file without extracting it
        with zipfile.ZipFile(io.BytesIO(file_content), 'r') as zip_file:
            zip_file.testzip()
        return True
    except zipfile.BadZipFile:
        return False
    
    
    
# def upload_bytes_to_s3(file_bytes, bucket_name, s3_key):
#     # Create an S3 client
#     s3 = boto3.client('s3')
#     try:
#         # Upload the file in bytes
#         s3.put_object(Body=file_bytes, Bucket=bucket_name, Key=s3_key)
#         st.success(f"File uploaded successfully to s3://{bucket_name}/{s3_key}")
#     except Exception as e:
#         st.error(f"Error uploading file to S3: {e}") 


def upload_bytes_to_s3(file_bytes, bucket_name, s3_key):
    # Create an S3 client
    s3 = boto3.client('s3')
 
    try:
        # Upload the file in bytes
        s3.put_object(Body=file_bytes, Bucket=bucket_name, Key=s3_key)
        st.success(f"File uploaded successfully to s3://{bucket_name}/{s3_key}")
    except Exception as e:
        st.error(f"Error uploading file to S3: {e}")
    


def unzip_and_upload_to_s3(uploaded_file, bucket_name, s3_folder):
    # Read the contents of the uploaded file
    file_bytes = uploaded_file.read()
 
    # Check if the file is a zip file
    is_zip_file = zipfile.is_zipfile(BytesIO(file_bytes))
 
    if is_zip_file:
        # If it's a zip file, unzip its contents
        with zipfile.ZipFile(BytesIO(file_bytes), 'r') as zip_ref:
            for file_info in zip_ref.infolist():
                # Read file content in bytes
                extracted_file_bytes = zip_ref.read(file_info.filename)
                # Create S3 key by combining the specified folder with the file name
                s3_key = f"{s3_folder}/{file_info.filename.split('/')[-1]}"  # Get the file name only
 
                # Upload bytes to S3
                upload_bytes_to_s3(extracted_file_bytes, bucket_name, s3_key)
    else:
        # If it's not a zip file, directly upload the contents
        s3_key = f"{s3_folder}/{uploaded_file.name}"
        upload_bytes_to_s3(file_bytes, bucket_name, s3_key)
 
    
def application_confirmation():
    application_id = st.session_state['applicationid']
    
    # Later we will set this at last if no error comes
#     st.session_state['page'] = 'SubmitPage'
#     st.text(f"session state page: {st.session_state['page']}")
    
#     st.text(f"The Final Data Object: {st.session_state['data_object']}")
#     st.text(f"Username{st.session_state['username']}")

#     st.session_state['user_id'] = st.experimental_get_query_params().get("user_id", [""])[0]
    try:
        st.session_state['user_id'] = st.query_params["user_id"]
    except KeyError:
        "No user_id has passed in URL"
    
    user_id = st.session_state['user_id']
    st.text(f'user_id: {user_id}')
    
    ctx = snowflake_conn()
    
    # Define language to locale mapping
    language_to_locale = {
        "english": "english",
        "japanese": "japanese",
        # Add more languages as needed
    }

    # Define CSV file mapping
    csv_file_mapping = {
        "english": "english",
        "japanese": "japanese"
    }

    # Get the language from the URL parameter
#     language = st.experimental_get_query_params().get("language", [""])[0]
    try:
        language = st.query_params["language", "english"]
    except KeyError:
        language = "english"

    # Set the language in session state
    st.session_state.language = language

    # Map the language to a locale (default to "english" if not found)
    locale = language_to_locale.get(language, "english")

    # Load language-specific CSV file
    lang_dict = load_bundle(locale, csv_file_mapping)


    ApplyForDataIngestionJob_key = 'ApplyforDataIngestionJob'
    ApplyForDataIngestionJob_text = lang_dict.get(ApplyForDataIngestionJob_key, ApplyForDataIngestionJob_key)
    # Set the title of the app
    st.title(lang_dict.get(ApplyForDataIngestionJob_text,ApplyForDataIngestionJob_text))

    # Create a container to hold the DI information
    di_information = st.container()
    
    DIInformation_key = 'DIInformation'
    DIInformation_key_text = lang_dict.get(DIInformation_key, DIInformation_key)
    
    # Add the DI information to the DI information container
    di_information.text(DIInformation_key_text)
    
     # Global capability
#     # Add a selectbox for Global Capability
#     global_capability_key = 'GlobalCapability'
#     global_capability_text = lang_dict.get(global_capability_key, global_capability_key)
#     global_capability = st.selectbox(global_capability_text, ["Select", "sales", "aftersales"])
    
    
    ProjectID_key = 'ProjectID'
    ProjectID_text = lang_dict.get(ProjectID_key, ProjectID_key)

    
    # Add a text input for the project ID
    project_id = st.text_input(lang_dict.get(ProjectID_text,ProjectID_text), placeholder="Example: FR01234")

    # # Stage
#     Stage_key = 'Stage'
#     Stage_text = lang_dict.get(Stage_key, Stage_key)
#     # Add a selectbox for the stage of the project
#     stage = st.selectbox(Stage_text, ["Select", "QA", "PROD"])
    

    # Create a container to hold the application materials
    application_materials = st.container()
    
    ApplicationMaterials_key = 'ApplicationMaterials'
    ApplicationMaterials_text = lang_dict.get(ApplicationMaterials_key, ApplicationMaterials_key)
    

    # Add the application materials to the application materials container
    application_materials.subheader(ApplicationMaterials_text)
    uploaded_application_form = application_materials.file_uploader("Application Form", type=["pdf", "doc", "docx","xlsx"])
    uploaded_sample = application_materials.file_uploader("Sample", type=["pdf", "doc", "docx","xlsx","zip"])
    uploaded_supplementary = application_materials.file_uploader("Supplementary", type=["pdf", "doc", "docx","xlsx","zip"])
    
    
    # Flag to check if the file has been processed
    file_processed = False
    
    
    
    # Initialize session state if not already done
    if 'uploaded_files' not in st.session_state:
        st.session_state.uploaded_files = {}
    
    # Create a column for the buttons
    col1, col2 = st.columns(2)

    # Add the buttons to the columns
    with col1:
        submit_button = st.button('Submit')

    with col2:
        modify_button = st.button('Modify')

        
    
    if submit_button:
        
        if st.session_state['reapplication']:

            sheet_name = "ContactList"
            selfdi_app_id = st.session_state['app_id']

            
            df = read_excel(uploaded_application_form, sheet_name)
            df = process_dataframe(df)
            st.text(f"DataFrame: {df}")
    #         snowflake_conn = sf_connection()
            select_qry = f"SELECT SELFDI_APP_ID FROM T_CONTACT;"
            result = execute_query(ctx, select_qry)
            status = response(result, selfdi_app_id,df,ctx)
            
            st.text(f"Status: {status}")
            app_id = st.session_state['applicationid']
            st.text(f"app_id: {app_id}")
            
            uploaded_files = create_uploaded_file(project_id, uploaded_application_form, uploaded_sample, uploaded_supplementary)

            # app_id = '2024010051'
    #         app_id = st.session_state['app_id']
            s3_bkt_name = "nml-nissan-data-qa-diapplication"

            file_name = f"{app_id}_Nissan.DATA.DataIngestion_{project_id}_ApplicationForm.xlsx"

            s3_loc = f"s3://{s3_bkt_name}/{project_id}/{app_id}/{file_name}"
    #         st.text("s3_key is:",s3_key)
            st.session_state['s3_key'] = s3_loc

            data_object = create_data_object(app_id, s3_loc, uploaded_files)
            st.session_state['data_object'] = data_object
               
     #           Below code works, Do not remove
            if uploaded_application_form:
                s3_url = upload_to_s3(uploaded_application_form.getvalue(), s3_bkt_name, project_id, app_id, file_name)
                if s3_url:
                    st.success(f"Application.xlsx uploaded to S3 successfully. S3 URL: {s3_url}")
                else:
                    st.error("Failed to upload Application.xlsx to S3. Check the logs for details.")


            if uploaded_sample:
                sample_file_name = uploaded_sample.name
                file_content = uploaded_sample.getvalue()
                st.text(f"file_content: {file_content}")
    #             st.text(f"zipped or not: {is_zip_file(file_content)}")

                if sample_file_name[-5:] == '.xlsx':
                    s3_url = upload_to_s3(file_content, s3_bkt_name, project_id, app_id, sample_file_name)
                    st.text(".xlsx file has been uploaded")


    #         app_id_to_fetch = '2024010051'
            app_id_to_fetch = app_id
            entry_query = f"SELECT * FROM T_ENTRY WHERE SELFDI_APP_ID = '{app_id_to_fetch}'"

            cursor = ctx.cursor()
            cursor.execute(entry_query)
            st.text(cursor.execute(entry_query))
            
            entry_data = cursor.fetchall()
            
            st.text(entry_data)

            if entry_data:
                # Unpack the data
                (
                    selfdi_app_id,
                    attempt,
                    prjct_id,
                    application_form,
                    sample_file,
                    supplementary,
                    storage_location,
                    crt_usr_id,
                    crt_dttm,
                    updt_usr_id,
                    updt_dttm,
                ) = entry_data[0]


                prjct_id = uploaded_files.get('project_id', '')
                application_form = uploaded_files.get('application_form_name', '')
                sample_file = uploaded_files.get('sample_name', '')
#                 supplementary = uploaded_files.get('supplementary_name', '')
                supplementary = 'Y' if uploaded_files.get('supplementary_name') else 'N'
                supplementary = bool(uploaded_files.get('supplementary_name'))


#                 # Use the unpacked values as needed
#                 st.text(f"SELFDI_APP_ID: {selfdi_app_id}")
#                 st.text(f"ATTEMPT: {attempt}")
#                 st.text(f"PRJCT_ID: {prjct_id}")
#                 st.text(f"Application Form: {application_form}")
#                 st.text(f"Sample File: {sample_file}")
#                 st.text(f"Supplementary: {'Y' if supplementary else 'N'}")
#                 st.text(f"Storage Location: {storage_location}")
#                 st.text(f"CRT_USR_ID: {crt_usr_id}")
#                 st.text(f"CRT_DTTM: {crt_dttm}")
#                 st.text(f"UPDT_USR_ID: {updt_usr_id}")
#                 st.text(f"UPDT_DTTM: {updt_dttm}")

                # Delete the existing record
                delete_query = f"DELETE FROM T_ENTRY WHERE SELFDI_APP_ID = '{selfdi_app_id}'"
                ctx.cursor().execute(delete_query)
                st.text(f"Deleted record with SELFDI_APP_ID: {selfdi_app_id}")

                # Increment the ATTEMPT value and insert a new record
                new_attempt = attempt + 1
                insert_query = f"""
                    INSERT INTO T_ENTRY (
                        SELFDI_APP_ID, ATTMPT, PRJCT_ID, APPLICTINFRM, SMPL_FL,
                        SPPLMNTRY, STRG_LCTN, CRT_USR_ID, CRT_DTTM, UPDT_USR_ID, UPDT_DTTM
                    ) VALUES (
                        '{selfdi_app_id}', {new_attempt}, '{prjct_id}', '{application_form}', '{sample_file}',
                        {supplementary}, '{storage_location}', '{crt_usr_id}', '{crt_dttm}', '{updt_usr_id}', '{updt_dttm}'
                    )
                """

                st.text(f"Insert query: {insert_query}")
                ctx.cursor().execute(insert_query)
                st.text(f"Inserted new record with SELFDI_APP_ID: {selfdi_app_id} and ATTEMPT: {new_attempt}")
                st.session_state['page'] = 'SubmitPage'
                st.session_state['submit_successfully_page_flag'] = True
                st.rerun()
    
            else:
                st.error(f"No data found for SELFDI_APP_ID: {app_id_to_fetch}")


       
        else:
            # To be set at last if no error
            st.session_state['page'] = 'SubmitPage'


            st.session_state['submit_successfully_page_flag'] = True



            sheet_name = "ContactList"




            df = read_excel(uploaded_application_form, sheet_name)
            df = process_dataframe(df)
    #         st.text(f"DataFrame: {df}")
    #         snowflake_conn = sf_connection()
            select_qry = f"SELECT SELFDI_APP_ID FROM T_CONTACT;"
            result = execute_query(ctx, select_qry)
    #         st.text(f"result : {result}")

            st.text(f"AppId: {st.session_state['app_id']}")
            selfdi_app_id = st.session_state['app_id']
    #         selfdi_app_id = "2024010083"
            status = response(result, selfdi_app_id,df,ctx)



    #         ### Below code works, Do not remove
            uploaded_files = create_uploaded_file(project_id, uploaded_application_form, uploaded_sample, uploaded_supplementary)
    #         st.text(f"Uploaded files: {uploaded_files}")


            app_id = st.session_state['app_id']


            s3_bkt_name = "nml-nissan-data-qa-diapplication"
            file_name = f"{app_id}_Nissan.DATA.DataIngestion_{project_id}_ApplicationForm.xlsx"
            s3_loc = f"s3://{s3_bkt_name}/{project_id}/{app_id}/{file_name}"
    #         st.text("s3_key is:",s3_key)
            st.session_state['s3_key'] = s3_loc


            if st.session_state['first_data_object']: 
    #             st.text(f"Inside first_obj_block")
                data_object = create_data_object(app_id, s3_loc, uploaded_files)
                st.session_state['data_object'] = data_object

                if uploaded_application_form:
                    st.text("Inside uploaded application form in Confirmation")
                    s3_url = upload_to_s3(uploaded_application_form.getvalue(), s3_bkt_name, project_id, app_id, file_name)
                    if s3_url:
                        st.success(f"Application.xlsx uploaded to S3 successfully. S3 URL: {s3_url}")
                    else:
                        st.error("Failed to upload Application.xlsx to S3. Check the logs for details.")



                if uploaded_sample:
                    sample_file_name = uploaded_sample.name
                    file_content = uploaded_sample.getvalue()

                    if sample_file_name[-5:] == '.xlsx':
                        s3_url = upload_to_s3(file_content, s3_bkt_name, project_id, app_id, sample_file_name)
    #                     st.text("xlsx file has been uploaded")

                    else:
                        try:
                            # Specify your S3 bucket name and folder
                            s3_bucket_name = 'nml-nissan-data-qa-diapplication'
                            s3_folder = f'{project_id}/{app_id}'

                            # Unzip and upload to S3
                            unzip_and_upload_to_s3(uploaded_sample, s3_bucket_name, s3_folder)

                        except Exception as e:
                            st.error(f"Error during processing: {e}")


                if uploaded_supplementary:
                    sample_file_name = uploaded_supplementary.name
                    file_content = uploaded_supplementary.getvalue()

                    if sample_file_name[-5:] == '.xlsx':
                        s3_url = upload_to_s3(file_content, s3_bkt_name, project_id, app_id, sample_file_name)
    #                     st.text("xlsx file has been uploaded")

                    else:
                        try:
                            # Specify your S3 bucket name and folder
                            s3_bucket_name = 'nml-nissan-data-qa-diapplication'
                            s3_folder = f'{project_id}/{app_id}'

                            # Unzip and upload to S3
                            unzip_and_upload_to_s3(uploaded_supplementary, s3_bucket_name, s3_folder)

                        except Exception as e:
                            st.error(f"Error during processing: {e}")


                # Execute insert query
                insert_query = execute_insert_query(ctx, data_object)
        #             insert_query = execute_insert_query()
                ctx.cursor().execute(insert_query)
    #             st.text("Insert query executed successfully! first time")

                st.session_state['Data_object'] =  data_object
    #             st.text(f"Data object: {data_object}")


                st.session_state['page'] = 'SubmitPage'     

                st.rerun()
            else:

    #             st.text('outside first obj')
                data_object = st.session_state['data_object']
    #             st.text(f"Data OBJ From reapp: {data_object}")
                insert_query = execute_insert_query(ctx, data_object)
                ctx.cursor().execute(insert_query)
    #             st.text("Insert query executed successfully!")
                st.rerun()

        
    if modify_button:
        st.write('Modify button clicked')
        
        # Check if the key exists before accessing it
        if 'application_form' in st.session_state.uploaded_files:
            st.text(st.session_state.uploaded_files['application_form'].name)
        else:
            st.text("No application form uploaded yet.")

    
if __name__ == "__main__":
    # application_confirmation()
    pass

