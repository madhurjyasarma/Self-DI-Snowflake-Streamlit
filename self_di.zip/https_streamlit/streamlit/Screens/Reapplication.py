import streamlit as st
import pandas as pd
import snowflake.connector
import openpyxl
from datetime import datetime

import boto3

from botocore.exceptions import NoCredentialsError

def snowflake_conn():
    SNOW_ACCOUNT = 'of95864.ap-northeast-1.privatelink'
    SNOW_USER = 'NDH00883'
    SNOW_PASS = 'Ni$$an@785685'
    SNOW_ROLE = 'SANDBOX_NDI_PF_DEV'
    SNOW_DB = 'SELF_DI'
    SNOW_SCHEMA = 'PUBLIC'
    SNOW_WAREHOUSE = 'SANDBOX_NDI_PF_DEV'

    # Connect to Snowflake table
    ctx = snowflake.connector.connect(
        user=SNOW_USER,
        password=SNOW_PASS,
        account=SNOW_ACCOUNT,
        role=SNOW_ROLE,
        warehouse=SNOW_WAREHOUSE,
        database=SNOW_DB,
        schema=SNOW_SCHEMA
    )

    cs = ctx.cursor()

    return ctx


def get_column_names(sheet):
    # Extract column names from the first row of the sheet
    return [col.value for col in sheet[1]]

def load_bundle(locale, csv_file_mapping):
    csv_file_path = f"streamlit/csv/{csv_file_mapping[locale]}.csv"
    try:
        df = pd.read_csv(csv_file_path)
        lang_dict = {df.key.to_list()[i]: df.value.to_list()[i] for i in range(len(df.key.to_list()))}
        return lang_dict
    except FileNotFoundError:
        st.error(f"CSV file not found at path: {csv_file_path}")
        return {}
    except Exception as e:
        st.error(f"An error occurred while loading the CSV file: {e}")
        return {}


    
def check_id_exist_in_contact(ctx, logged_in_user_id):
    try:
        cs = ctx.cursor()

        # Query to check if the logged-in User ID (Corporate ID) exists in T_CONTACT table
        query = f"SELECT COUNT(*) FROM T_CONTACT WHERE USR_ID = '{logged_in_user_id}'"
        cs.execute(query)
        result = cs.fetchone()[0]
#         st.text(f"result {result}")

        # Check the result
        if result == 0:
            st.error(f"{logged_in_user_id} is not accepted for updating application.")
            st.stop()  # Stop further processing
            

    except Exception as e:
        st.error(f"An error occurred while checking User ID in T_CONTACT table: {e}")
        st.stop()


def create_uploaded_file(project_id, uploaded_application_form, uploaded_sample, uploaded_supplementary):
    uploaded_files = {
        'application_form_name': uploaded_application_form.name if uploaded_application_form else None,
        'sample_name': uploaded_sample.name if uploaded_sample else None,
        'supplementary_name': uploaded_supplementary.name if uploaded_supplementary else None,
        'project_id': project_id
    }
    st.session_state.uploaded_files = uploaded_files
#     st.text("Variables set in session_state")
    return uploaded_files        
        
def create_data_object(app_id, s3_loc, uploaded_files):
#     st.text(f"Uploaded files: {uploaded_files}")
    data_object = {
        'SELFDI_APP_ID': app_id,
        'ATTMPT': 1,
        'PRJCT_ID': uploaded_files.get('project_id', ''),
        'APPLICTINFRM': uploaded_files.get('application_form_name', ''),
        'SMPL_FL': uploaded_files.get('sample_name', ''),
        'SPPLMNTRY': 'Y' if uploaded_files.get('supplementary_name') else 'N',
        'STRG_LCTN': s3_loc,
        'CRT_USR_ID': 'ND00883',
        'CRT_DTTM': datetime.now().strftime('%Y-%m-%d %H:%M:%S -08:00'),
        'UPDT_USR_ID': 'NDH00883',
        'UPDT_DTTM': datetime.now().strftime('%Y-%m-%d %H:%M:%S -08:00')
    }

    return data_object


def create_uploaded_file(project_id, uploaded_application_form, uploaded_sample, uploaded_supplementary):
    uploaded_files = {
        'application_form_name': uploaded_application_form.name if uploaded_application_form else None,
        'sample_name': uploaded_sample.name if uploaded_sample else None,
        'supplementary_name': uploaded_supplementary.name if uploaded_supplementary else None,
        'project_id': project_id
    }
    st.session_state.uploaded_files = uploaded_files
#     st.text("Variables set in session_state")
    return uploaded_files


def upload_to_s3(file_content, bucket_name, project_id, application_id,file_name):
    s3 = boto3.client('s3')

    try:
        # Format the S3 key based on the specified path structure
        s3_key = f"{project_id}/{application_id}/{file_name}"

        # Upload the file content to S3
        s3.put_object(Body=file_content, Bucket=bucket_name, Key=s3_key)

        print(f"File uploaded successfully to S3: s3://{bucket_name}/{s3_key}")
        return f"s3://{bucket_name}/{s3_key}"

    except NoCredentialsError:
        print("AWS credentials not available or invalid. Please check your credentials.")
        return None

def reapplication():
    
    st.session_state['first_data_object'] = False

#     st.text("Reapplication Page")
    ctx = snowflake_conn()
    
    app_id = st.session_state['applicationid']
    user_id = st.session_state['username']
    
#     st.session_state['fromReapplication'] = False
    
#     st.text(app_id)
#     st.text(st.session_state['username'])
    
    
    check_id_exist_in_contact(ctx,user_id)
       
    
    # Define language to locale mapping
    language_to_locale = {
        "english": "english",
        "japanese": "japanese",
        # Add more languages as needed
    }

    # Define CSV file mapping
    csv_file_mapping = {
        "english": "english",
        "japanese": "japanese"
    }

    # Get the language from the URL parameter
#     language = st.experimental_get_query_params().get("language", [""])[0]
    try:
        language = st.query_params["language"] 
    except KeyError:
        language = "english"

    # Set the language in session state
    st.session_state.language = language

    # Map the language to a locale (default to "english" if not found)
    locale = language_to_locale.get(language, "english")

    # Load language-specific CSV file
    lang_dict = load_bundle(locale, csv_file_mapping)


    ApplyForDataIngestionJob_key = 'ApplyforDataIngestionJob'
    ApplyForDataIngestionJob_text = lang_dict.get(ApplyForDataIngestionJob_key, ApplyForDataIngestionJob_key)
    # Set the title of the app
    st.title(lang_dict.get(ApplyForDataIngestionJob_text,ApplyForDataIngestionJob_text))

    # Create a container to hold the DI information
    di_information = st.container()
    
    DIInformation_key = 'DIInformation'
    DIInformation_key_text = lang_dict.get(DIInformation_key, DIInformation_key)
    
    # Add the DI information to the DI information container
    di_information.text(DIInformation_key_text)
    
    
    # Add a selectbox for Global Capability
#     global_capability_key = 'GlobalCapability'
#     global_capability_text = lang_dict.get(global_capability_key, global_capability_key)
#     global_capability = st.selectbox(global_capability_text, ["Select", "sales", "aftersales"])
    
    
    ProjectID_key = 'ProjectID'
    ProjectID_text = lang_dict.get(ProjectID_key, ProjectID_key)

    
    # Add a text input for the project ID
    project_id = st.text_input(lang_dict.get(ProjectID_text,ProjectID_text), placeholder="Example: FR01234")

#     Stage_key = 'Stage'
#     Stage_text = lang_dict.get(Stage_key, Stage_key)
#     # Add a selectbox for the stage of the project
#     stage = st.selectbox(Stage_text, ["Select", "QA", "PROD"])

    # Create a container to hold the application materials
    application_materials = st.container()
    
    ApplicationMaterials_key = 'ApplicationMaterials'
    ApplicationMaterials_text = lang_dict.get(ApplicationMaterials_key, ApplicationMaterials_key)
    

    # Add the application materials to the application materials container
    application_materials.subheader(ApplicationMaterials_text)
    uploaded_application_form = application_materials.file_uploader("Application Form", type=["pdf", "doc", "docx","xlsx"])
    uploaded_sample = application_materials.file_uploader("Sample", type=["pdf", "doc", "docx","xlsx","zip"])
    uploaded_supplementary = application_materials.file_uploader("Supplementary", type=["pdf", "doc", "docx","xlsx","zip"])
    
#     st.text(uploaded_application_form)

    submit_button = st.button('Upload')

    
    if submit_button:
#         st.session_state['submit_successfully_page_flag'] = True
        st.session_state['reapplication'] = True
        

#         In reapplication create the data_obj pass it to Application confirmation
#         In Application Confirmation using the data_object Deleting the old record and insert new record
        
        
#         st.text("Button clicked")        
#         st.text(f"Prjct-id: {project_id}")
        
#         uploaded_files = create_uploaded_file(project_id, uploaded_application_form, uploaded_sample, uploaded_supplementary)
     
#         # app_id = '2024010051'
# #         app_id = st.session_state['app_id']
#         s3_bkt_name = "nml-nissan-data-qa-diapplication"
        
#         file_name = f"{app_id}_Nissan.DATA.DataIngestion_{project_id}_ApplicationForm.xlsx"
        
#         s3_loc = f"s3://{s3_bkt_name}/{project_id}/{app_id}/{file_name}"
# #         st.text("s3_key is:",s3_key)
#         st.session_state['s3_key'] = s3_loc
    
#         data_object = create_data_object(app_id, s3_loc, uploaded_files)
#         st.session_state['data_object'] = data_object

#         st.text(f"Data object: {data_object}")
   
        st.session_state['page'] = 'application_confirmation'
#         st.text(f"Inside Reapplication -- 260 ")

        st.session_state['fromReapplication'] = True
#         st.text(f"Inside Reapplication -- 263 ")
        
        st.session_state['first_data_object'] = False
#         st.text(f"Inside Reapplication -- 266 ")
        
        
        st.rerun()
        
        
     
    
    
    
    
#  #           Below code works, Do not remove
#         if uploaded_application_form:
#             s3_url = upload_to_s3(uploaded_application_form.getvalue(), s3_bkt_name, project_id, app_id, file_name)
#             if s3_url:
#                 st.success(f"Application.xlsx uploaded to S3 successfully. S3 URL: {s3_url}")
#             else:
#                 st.error("Failed to upload Application.xlsx to S3. Check the logs for details.")
        

#         if uploaded_sample:
#             sample_file_name = uploaded_sample.name
#             file_content = uploaded_sample.getvalue()
#             st.text(f"file_content: {file_content}")
# #             st.text(f"zipped or not: {is_zip_file(file_content)}")

#             if sample_file_name[-5:] == '.xlsx':
#                 s3_url = upload_to_s3(file_content, s3_bkt_name, project_id, app_id, sample_file_name)
#                 st.text(".xlsx file has been uploaded")
    
        
# #         app_id_to_fetch = '2024010051'
#         app_id_to_fetch = app_id
#         entry_query = f"SELECT * FROM T_ENTRY WHERE SELFDI_APP_ID = '{app_id_to_fetch}'"

#         cursor = ctx.cursor()
#         cursor.execute(entry_query)
#         entry_data = cursor.fetchall()

#         if entry_data:
#             # Unpack the data
#             (
#                 selfdi_app_id,
#                 attempt,
#                 prjct_id,
#                 application_form,
#                 sample_file,
#                 supplementary,
#                 storage_location,
#                 crt_usr_id,
#                 crt_dttm,
#                 updt_usr_id,
#                 updt_dttm,
#             ) = entry_data[0]
            
            
#             prjct_id = uploaded_files.get('project_id', '')
#             application_form = uploaded_files.get('application_form_name', '')
#             sample_file = uploaded_files.get('sample_name', '')
#             supplementary = uploaded_files.get('supplementary_name', '')

           
            
#             # Use the unpacked values as needed
#             st.text(f"SELFDI_APP_ID: {selfdi_app_id}")
#             st.text(f"ATTEMPT: {attempt}")
#             st.text(f"PRJCT_ID: {prjct_id}")
#             st.text(f"Application Form: {application_form}")
#             st.text(f"Sample File: {sample_file}")
#             st.text(f"Supplementary: {'Y' if supplementary else 'N'}")
#             st.text(f"Storage Location: {storage_location}")
#             st.text(f"CRT_USR_ID: {crt_usr_id}")
#             st.text(f"CRT_DTTM: {crt_dttm}")
#             st.text(f"UPDT_USR_ID: {updt_usr_id}")
#             st.text(f"UPDT_DTTM: {updt_dttm}")

#             # Delete the existing record
#             delete_query = f"DELETE FROM T_ENTRY WHERE SELFDI_APP_ID = '{selfdi_app_id}'"
#             ctx.cursor().execute(delete_query)
#             st.text(f"Deleted record with SELFDI_APP_ID: {selfdi_app_id}")

#             # Increment the ATTEMPT value and insert a new record
#             new_attempt = attempt + 1
#             insert_query = f"""
#                 INSERT INTO T_ENTRY (
#                     SELFDI_APP_ID, ATTMPT, PRJCT_ID, APPLICTINFRM, SMPL_FL,
#                     SPPLMNTRY, STRG_LCTN, CRT_USR_ID, CRT_DTTM, UPDT_USR_ID, UPDT_DTTM
#                 ) VALUES (
#                     '{selfdi_app_id}', {new_attempt}, '{prjct_id}', ''{application_form}'', '{sample_file}',
#                     {supplementary}, '{storage_location}', '{crt_usr_id}', '{crt_dttm}', '{updt_usr_id}', '{updt_dttm}'
#                 )
#             """
            
#             st.text(f"Insert query: {insert_query}")
#             ctx.cursor().execute(insert_query)
#             st.text(f"Inserted new record with SELFDI_APP_ID: {selfdi_app_id} and ATTEMPT: {new_attempt}")
#         else:
#             st.error(f"No data found for SELFDI_APP_ID: {app_id_to_fetch}")













        
#         if uploaded_application_form:
#             # Load the Excel workbook
#             workbook = openpyxl.load_workbook(uploaded_application_form)

#             # List out sheet names
#             sheet_names = workbook.sheetnames
#             st.write("Sheet names:", sheet_names)

#         # Check if 'ContactList' sheet is present
#         if 'ContactList' in sheet_names:
#             st.write("\nDisplaying 'ContactList' sheet:")

#             # Get the 'ContactList' sheet
#             contact_list_sheet = workbook['ContactList']

#             # List out column names
#             column_names = get_column_names(contact_list_sheet)
#             st.write("Column names:", column_names)

#             # Access specific columns from the sheet
#             try:
#                 # Modify the column names as needed
#                 role_values = [row[1].value for row in contact_list_sheet.iter_rows(min_row=2, values_only=True)]
#                 dept_id_values = [row[2].value for row in contact_list_sheet.iter_rows(min_row=2, values_only=True)]
#                 first_name_values = [row[3].value for row in contact_list_sheet.iter_rows(min_row=2, values_only=True)]
#                 last_name_values = [row[4].value for row in contact_list_sheet.iter_rows(min_row=2, values_only=True)]
#                 corporate_id_values = [row[5].value for row in contact_list_sheet.iter_rows(min_row=2, values_only=True)]
#                 email_values = [row[6].value for row in contact_list_sheet.iter_rows(min_row=2, values_only=True)]

#                 # Display the retrieved values (you can customize this part)
#                 st.write(f"Role values: {role_values}")
#                 st.write(f"Dept ID values: {dept_id_values}")
#                 st.write(f"First Name values: {first_name_values}")
#                 st.write(f"Last Name values: {last_name_values}")
#                 st.write(f"Corporate ID values: {corporate_id_values}")
#                 st.write(f"Email Address values: {email_values}")

#                 # Continue with the rest of your processing...
#             except Exception as e:
#                 st.error(f"Error accessing columns: {e}")
#                 # Handle the error as needed
#         else:
#             st.error("'ContactList' sheet not found in the Excel file.")

#         st.rerun()



if __name__ == "__main__":
    reapplication()

