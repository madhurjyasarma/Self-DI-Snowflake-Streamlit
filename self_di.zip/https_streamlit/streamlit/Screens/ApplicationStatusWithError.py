import streamlit as st
import s3fs
import os


def download_file(bucket_name, object_key):
    bucket_name = bucket_name
    object_key = object_key
    local_file_name = 'downloaded_file.xlsx'
    
    s3 = s3fs.S3FileSystem()
    
    s3_path = f's3://{bucket_name}/{object_key}'
    
    print("Current Working Directory:", os.getcwd())

    # Download the object to a local file
    with s3.open(s3_path, 'rb') as s3_file, open(local_file_name, 'wb') as local_file:
        local_file.write(s3_file.read())

def application_status_with_error():
    
    if 'page' not in st.session_state:
        st.session_state['page'] ='Reapplication'
        
    st.title("Application Search with error")
    st.text(f"app_id from session: {st.session_state['applicationid']}")
    
    reapplication_button = st.button('Reapplication')
    download_button = st.button('Download')
    
    if reapplication_button:
        st.session_state.page = 'Reapplication'
        st.rerun()
        
    
    if download_button:
        st.text('Download file')
        bucket_name = 'nml-nissan-data-qa-diapplication'
        object_key = 'FR02303/2024010106/2024010106_Nissan.DATA.DataIngestion_FR02303_ApplicationForm.xlsx'
        download_file(bucket_name,object_key)
        st.text(f"File downloaded successfully at: {os.getcwd()}") 
    
