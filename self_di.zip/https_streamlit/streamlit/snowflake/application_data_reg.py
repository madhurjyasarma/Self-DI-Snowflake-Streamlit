import streamlit as st
import pandas as pd
import snowflake.connector
from snowflake.connector.pandas_tools import write_pandas

def snowflake_conn():
    SNOW_ACCOUNT ='of95864.ap-northeast-1.privatelink'
    SNOW_USER = 'NDH00883'
    SNOW_PASS = 'Ni$$an@785685'
    SNOW_ROLE = 'SANDBOX_NDI_PF_DEV'
    SNOW_DB = 'SELF_DI'
    SNOW_SCHEMA = 'PUBLIC'
    SNOW_WAREHOUSE = 'SANDBOX_NDI_PF_DEV'

    # Connect to Snowflake table
    ctx = snowflake.connector.connect(
        user=SNOW_USER,
        password=SNOW_PASS,
        account=SNOW_ACCOUNT,
        role=SNOW_ROLE,
        warehouse=SNOW_WAREHOUSE,
        database=SNOW_DB,
        schema=SNOW_SCHEMA
    )

    cs = ctx.cursor()
    
    return ctx
    
    
def data_prep():
    # Log Preparation
    table_columns = {
        'SELFDI_APP_ID': 'str',
        'ATTMPT': 'int',
        'PRJCT_ID': 'str',
        'APPLICTINFRM': 'str',
        'SMPL_FL': 'str',
        'SPPLMNTRY': 'str',
        'STRG_LCTN': 'str',
        'CRT_USR_ID': 'str',
        'CRT_DTTM': 'str',
        'UPDT_USR_ID': 'str',
        'UPDT_DTTM': 'str',
    }

    data_list = [
        {'SELFDI_APP_ID': '3', 'ATTMPT': 1,'PRJCT_ID': 'FR02304', 'APPLICTINFRM': 'ApplicationForm.xlsx', 
         'SMPL_FL': 'SampleFile.zip', 'SPPLMNTRY': 'Y', 'STRG_LCTN': 'S3://nml-dataplatform-production-datalake/xxx/xxxx/xx', 'CRT_USR_ID': 'madhurjya.goutamsharma@mail.nissan.co.jp', 
         'CRT_DTTM': '2023-03-20 18:45:00 -08:00', 'UPDT_USR_ID':'NDH00883','UPDT_DTTM':'2023-03-20 18:45:00 -08:00'},
        {'SELFDI_APP_ID': '4', 'ATTMPT': 1,'PRJCT_ID': 'FR02304', 'APPLICTINFRM': 'ApplicationForm.xlsx', 
         'SMPL_FL': 'SampleFile.zip', 'SPPLMNTRY': 'Y', 'STRG_LCTN': 'S3://nml-dataplatform-production-datalake/xxx/xxxx/xx', 'CRT_USR_ID': 'madhurjya.goutamsharma@mail.nissan.co.jp', 
         'CRT_DTTM': '2024-03-20 18:45:00 -08:00', 'UPDT_USR_ID':'NDH00883','UPDT_DTTM':'2024-03-20 18:45:00 -09:00'}
    ]

    df_entry = pd.DataFrame(data_list, columns=table_columns.keys())
    df_entry = df_entry.astype(table_columns)
    print(df_entry)
    
    return df_entry


def execute_data_insertion():
    
    ctx = snowflake_conn()
    df_entry = data_prep()
    # Log Registration
    table_name = 'T_ENTRY'
    
    success, nchunks, nrows, output = write_pandas(
        conn=ctx,
        df=df_entry,
        table_name=table_name
    )

    
if __name__ == "__main__":
    pass



