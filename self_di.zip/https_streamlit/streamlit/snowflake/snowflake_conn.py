import snowflake.connector

def snowflake_conn():
    SNOW_ACCOUNT ='of95864.ap-northeast-1.privatelink'
    SNOW_USER = 'NDH00883'
    SNOW_PASS = 'Ni$$an@785685'
    SNOW_ROLE = 'SANDBOX_NDI_PF_DEV'
    SNOW_DB = 'SELF_DI'
    SNOW_SCHEMA = 'PUBLIC'
    SNOW_WAREHOUSE = 'SANDBOX_NDI_PF_DEV'

    # Connect to Snowflake table
    ctx = snowflake.connector.connect(
        user=SNOW_USER,
        password=SNOW_PASS,
        account=SNOW_ACCOUNT,
        role=SNOW_ROLE,
        warehouse=SNOW_WAREHOUSE,
        database=SNOW_DB,
        schema=SNOW_SCHEMA
    )

    cs = ctx.cursor()
    
    return ctx